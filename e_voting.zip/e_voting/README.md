# Sistem E-Voting Pemilihan Ketua Organisasi Mahasiswa

Proyek ini merupakan simulasi sistem e-voting sederhana berbasis CLI menggunakan Python. Mahasiswa dapat memilih calon ketua organisasi dan melihat hasil pemilu secara real-time.

## Fitur Utama

* Input dan manajemen data pemilih
* Input dan manajemen data calon
* Proses voting dengan validasi satu suara per pemilih
* Statistik pemilu sederhana

## Struktur Folder

```text
e_voting/
├── main.py
├── modul/
│   ├── pemilih.py
│   ├── calon.py
│   ├── voting.py
│   ├── statistik.py
│   └── utils.py
├── data/
│   ├── pemilih.json
│   └── calon.json
└── README.md
```

## Cara Menjalankan

1. Pastikan Python 3 sudah terinstal.
2. Buka project menggunakan Visual Studio Code.
3. Jalankan file `main.py`.
4. Ikuti menu yang tersedia untuk menggunakan aplikasi.

## Dibuat oleh:

* **Nama:** Nayshila Salsabila Azzahra
* **NIM:** 20250040004
* **Kelas:** TI25G
