from modul.utils import baca_json, simpan_json

FILE_CALON = "data/calon.json"

def tambah_calon():
    data_calon = baca_json(FILE_CALON)

    print("\n===== TAMBAH DATA CALON =====")

    id_calon = input("Masukkan ID Calon : ")
    nama = input("Masukkan Nama Calon : ")
    visi = input("Masukkan Visi : ")

    # Cek apakah ID sudah digunakan
    for calon in data_calon:
        if calon["id"] == id_calon:
            print("ID calon sudah digunakan!")
            return

    # Tambahkan data calon baru
    calon_baru = {
        "id": id_calon,
        "nama": nama,
        "visi": visi,
        "jumlah_suara": 0
    }

    data_calon.append(calon_baru)

    # Simpan ke file JSON
    simpan_json(FILE_CALON, data_calon)

    print("Data calon berhasil ditambahkan.")