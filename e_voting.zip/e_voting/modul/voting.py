from modul.utils import baca_json, simpan_json

FILE_PEMILIH = "data/pemilih.json"
FILE_CALON = "data/calon.json"

def lakukan_voting():
    data_pemilih = baca_json(FILE_PEMILIH)
    data_calon = baca_json(FILE_CALON)

    print("\n===== VOTING =====")

    id_pemilih = input("Masukkan ID Pemilih : ")

    # Cek apakah pemilih ada
    pemilih = None
    for p in data_pemilih:
        if p["id"] == id_pemilih:
            pemilih = p
            break

    if pemilih is None:
        print("ID pemilih tidak ditemukan!")
        return

    # Cek apakah sudah memilih
    if pemilih["sudah_memilih"]:
        print("Pemilih sudah melakukan voting.")
        return

    print("\nDaftar Calon:")
    for calon in data_calon:
        print(f'{calon["id"]} - {calon["nama"]}')

    id_calon = input("Masukkan ID Calon yang dipilih : ")

    # Cek calon
    calon_terpilih = None
    for calon in data_calon:
        if calon["id"] == id_calon:
            calon_terpilih = calon
            break

    if calon_terpilih is None:
        print("ID calon tidak ditemukan!")
        return

    # Tambah suara
    calon_terpilih["jumlah_suara"] += 1

    # Ubah status pemilih
    pemilih["sudah_memilih"] = True

    # Simpan perubahan
    simpan_json(FILE_PEMILIH, data_pemilih)
    simpan_json(FILE_CALON, data_calon)

    print("Voting berhasil!")

def tampilkan_hasil():
    data_calon = baca_json(FILE_CALON)

    print("\n===== HASIL SEMENTARA =====")

    if len(data_calon) == 0:
        print("Belum ada data calon.")
        return

    for calon in data_calon:
        print(f'ID Calon      : {calon["id"]}')
        print(f'Nama          : {calon["nama"]}')
        print(f'Visi          : {calon["visi"]}')
        print(f'Jumlah Suara  : {calon["jumlah_suara"]}')
        print("-" * 30)